var searchData=
[
  ['realloc',['realloc',['../malloc_8h.html#a8499edb5f09d8455c15c667c36abaac6',1,'realloc(void *ptr, uint32_t size):&#160;malloc.c'],['../malloc_8c.html#a8499edb5f09d8455c15c667c36abaac6',1,'realloc(void *ptr, uint32_t size):&#160;malloc.c']]]
];
