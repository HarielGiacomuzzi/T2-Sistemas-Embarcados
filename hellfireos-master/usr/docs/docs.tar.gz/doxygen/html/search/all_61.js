var searchData=
[
  ['align',['align',['../malloc_8h.html#a1e0a98b5055eebe08414396335357f7f',1,'malloc.h']]],
  ['align_5fdummy',['align_dummy',['../unionmem__header__union.html#a5ca4f0da25cd2b76029162df7bdb537c',1,'mem_header_union']]],
  ['app_5fmain',['app_main',['../main_8h.html#a630544a7f0a2cc40d8a7fefab7e2fe70',1,'main.h']]]
];
