var searchData=
[
  ['queue',['queue',['../structqueue.html',1,'']]]
];
