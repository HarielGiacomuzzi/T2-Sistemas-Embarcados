var searchData=
[
  ['n_5fwaiting_5ftasks',['n_waiting_tasks',['../structmailbox.html#a7d31234908ebf91baf3dfbc8507f823e',1,'mailbox']]],
  ['name',['name',['../structtcb__entry.html#ad7bfcb0f4b58b797af44f3a078abebff',1,'tcb_entry']]],
  ['next',['next',['../structlist.html#a1900fe79e875e2838625b2eb60837f8f',1,'list::next()'],['../unionmem__header__union.html#a22eb41be35488312c1e42462d5679d64',1,'mem_header_union::next()'],['../structmem__block.html#ac3317f1b6603856e265b1ba15c4a99b8',1,'mem_block::next()']]]
];
