var searchData=
[
  ['ni_5finit',['ni_init',['../noc_8c.html#acb44cf0de3a986b823c53d881bff9568',1,'ni_init(void):&#160;noc.c'],['../noc_8h.html#acb44cf0de3a986b823c53d881bff9568',1,'ni_init(void):&#160;noc.c']]],
  ['ni_5fisr',['ni_isr',['../noc_8c.html#a7ca8f6357767be7d8d8f31a1f68902a1',1,'ni_isr(void *arg):&#160;noc.c'],['../noc_8h.html#a7ca8f6357767be7d8d8f31a1f68902a1',1,'ni_isr(void *arg):&#160;noc.c']]]
];
