var searchData=
[
  ['noc_5fcolumn',['NOC_COLUMN',['../noc_8h.html#a7713d5f2fc077c02e1e9ebd59731f95c',1,'noc.h']]],
  ['noc_5fline',['NOC_LINE',['../noc_8h.html#afe0b89f2b267056c1c677f527cae4185',1,'noc.h']]]
];
