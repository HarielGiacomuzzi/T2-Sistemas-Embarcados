var searchData=
[
  ['tail',['tail',['../structqueue.html#ada0fe9a078df1d07623c761f2e8376ad',1,'queue']]],
  ['task_5fcontext',['task_context',['../structtcb__entry.html#a589e6c94b17a97df5d22edf504acfd42',1,'tcb_entry']]]
];
