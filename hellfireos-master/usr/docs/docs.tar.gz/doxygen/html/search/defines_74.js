var searchData=
[
  ['task_5fblocked',['TASK_BLOCKED',['../kernel_8h.html#ac992e32269ecc3d8a38fd95b70cba372',1,'kernel.h']]],
  ['task_5fdelayed',['TASK_DELAYED',['../kernel_8h.html#a798d21ca82c245fd26f4a5f3efbd4014',1,'kernel.h']]],
  ['task_5fidle',['TASK_IDLE',['../kernel_8h.html#aa56ba1aed5aa073e789fd485da6202f0',1,'kernel.h']]],
  ['task_5fready',['TASK_READY',['../kernel_8h.html#a4b78a26b7a5f1543a2d0d5127fb0754a',1,'kernel.h']]],
  ['task_5frunning',['TASK_RUNNING',['../kernel_8h.html#a17e3f99a030e5dfefb8f9815600e3fed',1,'kernel.h']]],
  ['task_5fwaiting',['TASK_WAITING',['../kernel_8h.html#aa62d19f3e8e48cdbcd2259661c184fc3',1,'kernel.h']]]
];
