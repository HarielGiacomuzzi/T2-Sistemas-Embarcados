var searchData=
[
  ['s',['s',['../unionmem__header__union.html#a8e9bc77f2cf7596a7503f50ef29019f9',1,'mem_header_union']]],
  ['sched_5fbe',['sched_be',['../scheduler_8h.html#a52ecf98c89cb386c22223d19b1926202',1,'sched_be(void):&#160;scheduler.c'],['../scheduler_8c.html#a52ecf98c89cb386c22223d19b1926202',1,'sched_be(void):&#160;scheduler.c']]],
  ['sched_5frt',['sched_rt',['../scheduler_8h.html#ae63de031dbb9678f4ed0a1ac3e82ef2e',1,'sched_rt(void):&#160;scheduler.c'],['../scheduler_8c.html#ae63de031dbb9678f4ed0a1ac3e82ef2e',1,'sched_rt(void):&#160;scheduler.c']]],
  ['scheduler_2ec',['scheduler.c',['../scheduler_8c.html',1,'']]],
  ['scheduler_2eh',['scheduler.h',['../scheduler_8h.html',1,'']]],
  ['sem',['sem',['../structsem.html',1,'']]],
  ['sem_5fqueue',['sem_queue',['../structsem.html#a723ac960b2566b855b905fa4aa324f9b',1,'sem']]],
  ['sem_5ft',['sem_t',['../semaphore_8h.html#ad7630848c81d49708045a351922eb6b5',1,'semaphore.h']]],
  ['semaphore_2ec',['semaphore.c',['../semaphore_8c.html',1,'']]],
  ['semaphore_2eh',['semaphore.h',['../semaphore_8h.html',1,'']]],
  ['size',['size',['../structmem__chunk.html#a6c249814794488c18a42bcf180e3c024',1,'mem_chunk::size()'],['../unionmem__header__union.html#ab0a6578a8d52fd76a933d21273e73e08',1,'mem_header_union::size()'],['../structmem__block.html#a5ff4ee5dcd970bbc4951eb108c5eec4b',1,'mem_block::size()'],['../structqueue.html#af80cfabc36286195365b6d666d518504',1,'queue::size()']]],
  ['stack_5fsize',['stack_size',['../structtcb__entry.html#a2174ff4c5cf178e9dc3d652c472b23dd',1,'tcb_entry']]],
  ['state',['state',['../structtcb__entry.html#a67f430ab50cb8ff9133e133fc240f3d7',1,'tcb_entry']]]
];
