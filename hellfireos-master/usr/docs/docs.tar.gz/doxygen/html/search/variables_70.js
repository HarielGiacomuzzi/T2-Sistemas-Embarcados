var searchData=
[
  ['period',['period',['../structtcb__entry.html#a85e14b4c040e0535b45b52a7ee7c9a94',1,'tcb_entry']]],
  ['pktdrv_5fports',['pktdrv_ports',['../noc_8h.html#a28c51954b0e202d17770b6f597d58e35',1,'noc.h']]],
  ['pktdrv_5fqueue',['pktdrv_queue',['../noc_8h.html#ac96abbb61b929a8293778fe63006aca4',1,'noc.h']]],
  ['pktdrv_5ftqueue',['pktdrv_tqueue',['../noc_8h.html#a6e2b90dbd05cdac119b8d3296579de0a',1,'noc.h']]],
  ['preempt_5fcswitch',['preempt_cswitch',['../structpcb__entry.html#af49c7195c79f5de2d70825e2252c8d77',1,'pcb_entry']]],
  ['pstack',['pstack',['../structtcb__entry.html#a0434be5f20d1645ab2804b7ee5c95fc9',1,'tcb_entry']]],
  ['ptask',['ptask',['../structtcb__entry.html#a7ed7f2d228da0039f065f0c8a756b46d',1,'tcb_entry']]]
];
