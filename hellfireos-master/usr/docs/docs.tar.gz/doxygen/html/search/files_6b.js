var searchData=
[
  ['kernel_2eh',['kernel.h',['../kernel_8h.html',1,'']]],
  ['kprintf_2ec',['kprintf.c',['../kprintf_8c.html',1,'']]],
  ['kprintf_2eh',['kprintf.h',['../kprintf_8h.html',1,'']]]
];
