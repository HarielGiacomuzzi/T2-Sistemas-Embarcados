var searchData=
[
  ['id',['id',['../structtcb__entry.html#ac06c8d6513b9d3031956b0efc2ab4871',1,'tcb_entry']]],
  ['interrupts',['interrupts',['../structpcb__entry.html#ae5474e1d477335caf5515d8a940d1f77',1,'pcb_entry']]]
];
