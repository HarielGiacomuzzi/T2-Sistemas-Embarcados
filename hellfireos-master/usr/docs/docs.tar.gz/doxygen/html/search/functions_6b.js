var searchData=
[
  ['kprintf',['kprintf',['../kprintf_8h.html#a80682af286bf85737036e5c569ab942a',1,'kprintf(const int8_t *fmt,...):&#160;kprintf.c'],['../kprintf_8c.html#a80682af286bf85737036e5c569ab942a',1,'kprintf(const int8_t *fmt,...):&#160;kprintf.c']]]
];
