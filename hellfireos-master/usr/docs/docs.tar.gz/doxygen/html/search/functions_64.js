var searchData=
[
  ['dispatch_5fisr',['dispatch_isr',['../scheduler_8h.html#a606ec5940ea75925046ae6ebb7657800',1,'dispatch_isr(void *arg):&#160;scheduler.c'],['../scheduler_8c.html#a606ec5940ea75925046ae6ebb7657800',1,'dispatch_isr(void *arg):&#160;scheduler.c']]],
  ['dprintf',['dprintf',['../kprintf_8h.html#ad59de227a667120c5cd292e8882fa598',1,'dprintf(const int8_t *fmt,...):&#160;kprintf.c'],['../kprintf_8c.html#ad59de227a667120c5cd292e8882fa598',1,'dprintf(const int8_t *fmt,...):&#160;kprintf.c']]]
];
