var searchData=
[
  ['idletask',['idletask',['../main_8c.html#ac45a0aa39ad2d3a974d53a4d231dc20c',1,'main.c']]],
  ['init_5fqueues',['init_queues',['../main_8c.html#a30575bb68ade0cf71c6fa97be9b3f47b',1,'main.c']]]
];
